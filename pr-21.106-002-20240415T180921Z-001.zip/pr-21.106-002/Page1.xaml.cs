﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr_21._106_002
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        private int _countList = 0;
        private int fullCount;
        private int start;
        private int gender = 0;
        private string fnd = "";
        private int sort;
        private Client SelectedClient;
        private bool isEditingWindowOpen = false;

        public Page1()
        {
            InitializeComponent();
        }
        public void Load()
          
        {
            List<Client> clients = new List<Client>();
            if (fnd == "" || _countList == 0)
            {
                clients = helper.GetEntities().Client.ToList();
            }
            else
            {
                clients = helper.GetEntities().Client.Where(Agent => Agent.FirstName.Contains(fnd) || Agent.LastName.Contains(fnd) || Agent.Patronymic.Contains(fnd) || Agent.Phone.Contains(fnd) || Agent.Email.Contains(fnd)).Take(_countList).ToList();
            }
            if (gender != 0)
            {
                clients = clients.Where(o => o.GenderCode == gender.ToString()).ToList();
                fullCount = clients.Count;
            }
            else
            {
                fullCount = clients.Count;
            }
            if (_countList == 0) _countList = clients.Count;

            clients = clients.Skip(start * _countList).Take(_countList).ToList();

            ClientCount[] ClientsCount = new ClientCount[clients.Count];
            for (int i = 0; i < ClientsCount.Length; i++)
            {
                ClientsCount[i] = new ClientCount();
                ClientsCount[i].CurrentClient = clients[i];
            }
            var CountList = helper.GetEntities().ClientService.ToArray();
            if (sort == 1)
            {
                clients = clients.OrderBy(p => p.LastName).ToList();
            }
            else if (sort == 2)
            {
                for (int i = 0; i < clients.Count; i++)
                {
                    ClientService[] ClientsDate = CountList.Where(p => p.Client.ID == clients[i].ID).ToArray();
                    if (ClientsDate != null || ClientsDate.Length != 0)
                    {
                        var lastDate = ClientsDate.OrderByDescending(p => p.StartTime).FirstOrDefault();

                        if (lastDate != null)
                        {
                            ClientsCount[i].LastDate = lastDate.StartTime;
                        }
                    }
                }
                ClientsCount = ClientsCount.OrderByDescending(p => p.LastDate).ToArray();
                DateTime newDate = new DateTime();
                for (int i = 0; i < clients.Count; i++)
                {
                    if (ClientsCount[i].LastDate == newDate)
                    {
                        clients.Remove(clients[i]);
                        continue;
                    }
                    clients[i] = ClientsCount[i].CurrentClient;
                }
            }
            else if (sort == 3)
            {
                for (int i = 0; i < clients.Count; i++)
                {
                    ClientsCount[i].CountService = CountList.Count(p => p.Client == clients[i]);
                }
                ClientsCount = ClientsCount.OrderByDescending(p => p.CountService).ToArray();
                for (int i = 0; i < clients.Count; i++)
                {
                    clients[i] = ClientsCount[i].CurrentClient;
                }

            }
            else if (sort == 4)
            {
                clients = clients.Where(p => p.Birthday.Value.Month == DateTime.Now.Month).ToList();
            }

            agentGrid.ItemsSource = clients.ToList();
            full.Text = helper.GetEntities().Client.ToList().Count.ToString();
            current.Text = clients.Count.ToString();
            //pagin = full
            int ost = fullCount % _countList;
            var pag = (fullCount - ost) / _countList;
            if (ost > 0) pag++;
            pagin.Children.Clear();
            int maxButtons = 5;
            int startPage = Math.Max(1, start - maxButtons / 2);
            int endPage = Math.Min(startPage + maxButtons - 1, pag);

            for (int i = startPage; i <= endPage; i++)
            {
                Button myButton = new Button();
                myButton.Height = 30;
                myButton.Content = i;
                myButton.Width = 20;
                myButton.HorizontalAlignment = HorizontalAlignment.Center;
                myButton.Tag = i - 1;
                myButton.Click += new RoutedEventHandler(paginButto_Click);
                pagin.Children.Add(myButton);
            }

            // Добавляем многоточие и кнопку для последней страницы, если нужно
            if (startPage > 1)
            {
                Label ellipsisLabel = new Label();
                ellipsisLabel.Content = "...";
                ellipsisLabel.Height = 30;
                ellipsisLabel.Width = 20;
                ellipsisLabel.HorizontalAlignment = HorizontalAlignment.Center;
                pagin.Children.Insert(0, ellipsisLabel);

                Button firstButton = new Button();
                firstButton.Height = 30;
                firstButton.Content = 1;
                firstButton.Width = 20;
                firstButton.HorizontalAlignment = HorizontalAlignment.Center;
                firstButton.Tag = 0;
                firstButton.Click += new RoutedEventHandler(paginButto_Click);
                pagin.Children.Insert(0, firstButton);
            }

            if (endPage < pag)
            {
                Label ellipsisLabel = new Label();
                ellipsisLabel.Content = "...";
                ellipsisLabel.Height = 30;
                ellipsisLabel.Width = 20;
                ellipsisLabel.HorizontalAlignment = HorizontalAlignment.Center;
                pagin.Children.Add(ellipsisLabel);

                Button lastButton = new Button();
                lastButton.Height = 30;
                lastButton.Content = pag;
                lastButton.Width = 20;
                lastButton.HorizontalAlignment = HorizontalAlignment.Center;
                lastButton.Tag = pag - 1;
                lastButton.Click += new RoutedEventHandler(paginButto_Click);
                pagin.Children.Add(lastButton);
            }
            turnButton();



        }

        private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var index = CountList.SelectedIndex;
            if (index == 0) _countList = 10;
            if(index==1) _countList = 50;
            if(index==2) _countList = 200;
            if (index == 3) _countList = 0;
            Load();
        }
        private void paginButto_Click(object sender, RoutedEventArgs e)
        {
            start = Convert.ToInt32(((Button)sender).Tag.ToString());
            Load();
        }
        private void turnButton()
        {
            if (start == 0) { back.IsEnabled = false; }
            else { back.IsEnabled = true; };
            if ((start + 2) * 10 > fullCount) { forward.IsEnabled = false; }
            else { forward.IsEnabled = true; };
        }

        private void Type_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            gender = Type.SelectedIndex;
            Load();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            fnd = ((TextBox)sender).Text;
            Load();
        }

        private void agentGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void back_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            start--;
            Load();
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            start++;
            Load();
        }

        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedClient == null)
            {
                MessageBox.Show("Сначала нужно выбрать клиента!");
            }
            else if (!isEditingWindowOpen)
            {
                isEditingWindowOpen = true;
                ClientWindow clientWindow = new ClientWindow(SelectedClient);
                clientWindow.Closed += (s, args) => isEditingWindowOpen = false;
                clientWindow.Show();
            }
            else
            {
                MessageBox.Show("Окно редактирования уже открыто.");
            }
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            ClientWindow clientWindow = new ClientWindow();
            clientWindow.Show();
        }

        private void SortList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            sort = SortList.SelectedIndex;
            Load();
        }

        private void agentGrid_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Right)
            {
                var dataGrid = sender as DataGrid;
                if (dataGrid != null)
                {
                    var dataGridRow = FindVisualParent<DataGridRow>(e.OriginalSource as DependencyObject);
                    if (dataGridRow != null)
                    {
                        Client selectedItem = dataGrid.SelectedItem as Client;

                        if (selectedItem != null)
                        {
                            using (var context = helper.GetEntities())
                            {
                                
                                var entityToDelete = context.Client.FirstOrDefault(client => client.ID == selectedItem.ID);

                                if (entityToDelete != null)
                                {
                                    context.Client.Remove(entityToDelete);
                                    context.SaveChanges();
                                    agentGrid.ItemsSource = context.Client.ToList();
                                }
                            }
                        }
                    }
                }
            }
        }

        private static T FindVisualParent<T>(DependencyObject obj) where T : DependencyObject
        {
            while (obj != null)
            {
                if (obj is T)
                {
                    return (T)obj;
                }
                obj = VisualTreeHelper.GetParent(obj);
            }
            return null;
        }

        private void ClientDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (agentGrid.SelectedItem != null)
            {
                if (agentGrid.SelectedItem is Client selectedClient)
                {
                    SelectedClient = selectedClient;
                }
            }
        }
    }
    public class ClientCount
    {
        public Client CurrentClient;
        public int CountService;
        public DateTime LastDate;

    }
}
