﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace pr_21._106_002
{
    /// <summary>
    /// Логика взаимодействия для Client.xaml
    /// </summary>
    public partial class ClientWindow : Window
    {
        private Client firstClient;
        private string imagePath;
        private string imagePathData;
        public ClientWindow(Client currentClietn)
        {
            InitializeComponent();
            clients = helper.GetEntities().Client.ToList();
            firstClient = currentClietn;
            btnSave.Visibility = Visibility.Visible;
            btnAdd.Visibility = Visibility.Hidden;
            Load();
        }
        public ClientWindow()
        {
            InitializeComponent();
            clients = helper.GetEntities().Client.ToList();
            txtID.Visibility = Visibility.Hidden;
            lblID.Visibility = Visibility.Hidden;
            btnAdd.Visibility = Visibility.Visible;
            btnSave.Visibility = Visibility.Hidden;
        }
        List<Client> clients = new List<Client>();

        public void Load()
        {
            //firstClient = clients[IdAgent];
            txtID.Text = firstClient.ID.ToString();
            txtFirstName.Text = firstClient.LastName.ToString();
            txtLastName.Text = firstClient.FirstName.ToString();
            txtMiddleName.Text = firstClient.Patronymic.ToString();
            txtEmail.Text = firstClient.Email.ToString();
            txtPhone.Text = firstClient.Phone.ToString();
            imagePathData = firstClient.PhotoPath.ToString();
            imagePath = System.IO.Path.GetFullPath($"{imagePathData}");
            BitmapImage bitmap = new BitmapImage(new Uri(imagePath, UriKind.Absolute));
            imgPhoto.Source = bitmap;
            int gender = Convert.ToInt32(firstClient.GenderCode);
            cmbGender.SelectedIndex = gender - 1;
            DateTime birthDate = firstClient.Birthday.Value;
            string formattedDate = birthDate.ToString("yyyy-MM-dd");

            dpBirthDate.SelectedDate = DateTime.ParseExact(formattedDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);

            DateTime regDate = firstClient.RegistrationDate.Value;
            string formattedRegDate = regDate.ToString("yyyy-MM-dd");

            dpRegData.SelectedDate = DateTime.ParseExact(formattedRegDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        public void Save()
        {
            helper.GetEntities().SaveChanges();
        }
            
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckDate())
            {
                return;
            }
            Client newClient = new Client();

            newClient.PhotoPath = imagePathData;
            MessageBox.Show($"{imagePathData}");
            newClient.ID = clients[clients.Count - 1].ID + 1;
            newClient.FirstName = txtFirstName.Text;
            newClient.LastName = txtLastName.Text;
            newClient.Patronymic = txtMiddleName.Text;
            newClient.Email = txtEmail.Text;
            newClient.Phone = txtPhone.Text;
            newClient.GenderCode = (cmbGender.SelectedIndex + 1).ToString();
            newClient.Birthday = dpBirthDate.SelectedDate;
            newClient.RegistrationDate = dpRegData.SelectedDate;
            helper.GetEntities().Client.Add(newClient);
            Save();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckDate())
            {
                return;
            }
            Save();
        }
        private bool CheckDate()
        {
            if (!(new Regex(@"(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)")).IsMatch(txtEmail.Text))
            {
                MessageBox.Show("Неверные данные: mail@mail");
                return false; 
            }
            if (!(new Regex(@"^[0-9+\-\(\)\s]*$")).IsMatch(this.txtPhone.Text))
            {
                MessageBox.Show("Неверные данные: +7(000)000-00-00 ");
                return false;
            }
            if (!(new Regex(@"^[a-zA-Zа-яА-Я\s-]{1,50}$")).IsMatch($"{txtFirstName.Text} {txtMiddleName.Text} {txtLastName.Text}"))
            {
                MessageBox.Show("Неверные данные: Только буквы в ФИО");
                return false;
            }
            if ((cmbGender.SelectedIndex == -1))
            {
                MessageBox.Show("Необходим пол");
                return false;
            }
            return true;
        }

        private void btnSelectPhoto_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpeg;*.jpg)|*.png;*.jpeg;*.jpg|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                string selectedImagePath = openFileDialog.FileName;

                // Проверка размера файла (не более 2 МБ)
                FileInfo fileInfo = new FileInfo(selectedImagePath);
                long fileSizeInBytes = fileInfo.Length;
                long fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);

                if (fileSizeInMegabytes > 2)
                {
                    MessageBox.Show("Выбранный файл слишком большой. Максимальный размер - 2 МБ.");
                    return;
                }
                // Сохранение пути к выбранному изображению
                imagePathData = selectedImagePath.ToString();
                MessageBox.Show($"{imagePathData}");
                
            }
        }
    }
}
