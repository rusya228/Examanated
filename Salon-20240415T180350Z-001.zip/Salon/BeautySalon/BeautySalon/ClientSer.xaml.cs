﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BeautySalon
{
    /// <summary>
    /// Логика взаимодействия для ClientSer.xaml
    /// </summary>
    public partial class ClientSer : Window
    {
        public ClientSer(Client SelectedClient)
        {
            InitializeComponent();
            Load(SelectedClient);
        }

        public void Load(Client SelectedClient)
        {
            List<ClientService> clientsservice = helper.GetEntities().ClientService
                            .Where(cs => cs.Client.ID == SelectedClient.ID)
                            .ToList();


            InformationClient[] information = new InformationClient[clientsservice.Count];
            for (int i = 0; i < information.Length; i++)
            {
                var id = clientsservice[i].ServiceID;
                var name = helper.GetEntities().Service.ToArray()[i].Title;

                DateTime time = clientsservice[i].StartTime;

                var imagePath = helper.GetEntities().Service.ToArray()[i].MainImagePath; // Замените на фактическое свойство Service, содержащее путь к изображению
                information[i] = new InformationClient(name, time, imagePath);
            }
            serGrid.ItemsSource = information;
        }
    }
    public class InformationClient
    {
        public string NameService { set; get; }
        public DateTime TimeStart { set; get; }
        public string ImagePath { set; get; }

        public InformationClient(string nameService, DateTime timeStart, string imagePath)
        {
            NameService = nameService;
            TimeStart = timeStart;
            ImagePath = imagePath;
        }
    }
}
