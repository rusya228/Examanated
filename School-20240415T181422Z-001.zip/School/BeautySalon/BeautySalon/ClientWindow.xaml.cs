﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BeautySalon
{
    /// <summary>
    /// Логика взаимодействия для ClientWindow.xaml
    /// </summary>
    public partial class ClientWindow : Window
    {
        private Client firstClient;
        private string imagePath;
        public int lastId;
        public int newId;
        private string imagePathData;
        public ClientWindow(Client currentClietn)
        {
            InitializeComponent();
            clients = helper.GetEntities().Client.ToList();
            firstClient = currentClietn;
            btnSave.Visibility = Visibility.Visible;
            btnAdd.Visibility = Visibility.Hidden;
            Load();
        }
        public ClientWindow()
        {
            InitializeComponent();
            clients = helper.GetEntities().Client.ToList();
            txtID.Visibility = Visibility.Hidden;
            lblID.Visibility = Visibility.Hidden;
            btnAdd.Visibility = Visibility.Visible;
            btnSave.Visibility = Visibility.Hidden;
        }
        List<Client> clients = new List<Client>();

        public void Load()
        {
            //firstClient = clients[IdAgent];
            txtID.Text = firstClient.ID.ToString();
            txtFirstName.Text = firstClient.LastName.ToString();
            txtLastName.Text = firstClient.FirstName.ToString();
            txtMiddleName.Text = firstClient.Patronymic.ToString();
            txtEmail.Text = firstClient.Email.ToString();
            txtPhone.Text = firstClient.Phone.ToString();
            int gender = Convert.ToInt32(firstClient.GenderCode);
            cmbGender.SelectedIndex = gender - 1;
            DateTime birthDate = firstClient.Birthday.Value;
            string formattedDate = birthDate.ToString("yyyy-MM-dd");

            dpBirthDate.SelectedDate = DateTime.ParseExact(formattedDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);

            DateTime regDate = (DateTime)firstClient.RegistrationDate;
            string formattedRegDate = regDate.ToString("yyyy-MM-dd");

            dpRegData.SelectedDate = DateTime.ParseExact(formattedRegDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            UpdateTags();
        }

        public void Save()
        {
            helper.GetEntities().SaveChanges();
            MessageBox.Show("Данные обновлены");
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckDate())
            {
                return;
            }
            Client newClient = new Client();

            newClient.ID = clients[clients.Count - 1].ID + 1;
            newClient.LastName = txtLastName.Text;
            newClient.FirstName = txtFirstName.Text;
            newClient.Patronymic = txtMiddleName.Text;
            newClient.Email = txtEmail.Text;
            newClient.Phone = txtPhone.Text;
            newClient.GenderCode = (cmbGender.SelectedIndex + 1).ToString();
            newClient.Birthday = dpBirthDate.SelectedDate;
            newClient.RegistrationDate = dpRegData.SelectedDate.Value;
            helper.GetEntities().Client.Add(newClient);
            Save();
            ClientPage.Instance.Load();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {

            if (!CheckDate())
            {
                return;
            }
            firstClient.LastName = txtLastName.Text;
            firstClient.FirstName = txtFirstName.Text;
            firstClient.Patronymic = txtMiddleName.Text;
            firstClient.Email = txtEmail.Text;
            firstClient.Phone = txtPhone.Text;
            firstClient.GenderCode = (cmbGender.SelectedIndex + 1).ToString();
            firstClient.Birthday = dpBirthDate.SelectedDate;
            firstClient.RegistrationDate = dpRegData.SelectedDate.Value;
            Save();
            ClientPage.Instance.Load();

        }
        private bool CheckDate()
        {
            if (!(new Regex(@"(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)")).IsMatch(txtEmail.Text))
            {
                MessageBox.Show("Неверные данные: mail@mail");
                return false;
            }
            if (!(new Regex(@"^[0-9+\-\(\)\s]*$")).IsMatch(this.txtPhone.Text))
            {
                MessageBox.Show("Неверные данные: +7(000)000-00-00 ");
                return false;
            }
            if (!(new Regex(@"^[a-zA-Zа-яА-Я\s-]{1,50}$")).IsMatch($"{txtFirstName.Text} {txtMiddleName.Text} {txtLastName.Text}"))
            {
                MessageBox.Show("Неверные данные: Только буквы в ФИО");
                return false;
            }
            if ((cmbGender.SelectedIndex == -1))
            {
                MessageBox.Show("Необходим пол");
                return false;
            }
            return true;
        }


        private void UpdateTags()
        {
            
            lbTags.Items.Clear();
            lbTags.DisplayMemberPath = "Title";
            var clientTags = firstClient.TagOfClient
                .Where(tc => tc.ClientID == firstClient.ID)
                .Select(tc => tc.Tag)
                .ToList();
            //clientTags[0].
            //lbTags.DrawMode.

            for (int i = 0; i < clientTags.Count; i++)
            {
                ListBoxItem item = new ListBoxItem();
                Color color = new Color();
                string nameColor = clientTags[i].Color;
                //color = Color.FromRgb(255, 0, 0);
                if (nameColor.Contains("Red"))
                {
                    color = Color.FromRgb(255, 0, 0);
                }
                else if (nameColor.Contains("Blue"))
                {
                    color = Color.FromRgb(0, 0, 255);
                }
                else if (nameColor.Contains("Green"))
                {
                    color = Color.FromRgb(0, 255, 0);
                }
                item.Background = new SolidColorBrush(color);
                item.Content = clientTags[i].Title;
                lbTags.Items.Add(item);

            }

        }

        private void btnAddTag_Click(object sender, RoutedEventArgs e)
        {
            // Получите выбранный тег из ComboBox
            string selectedTagName = cmbTag.Text;

            if (!string.IsNullOrEmpty(selectedTagName))
            {
                // Проверьте, не прикреплен ли уже этот тег к клиенту
                if (!firstClient.TagOfClient.Any(tc => tc.Tag.Title == selectedTagName))
                {
                    // Проверьте, существует ли тег с выбранным именем в базе данных
                    Tag existingTag = helper.GetEntities().Tag.FirstOrDefault(t => t.Title == selectedTagName);

                    // Если тег не существует, создайте новый
                    if (existingTag == null)
                    {
                        existingTag = new Tag { Title = selectedTagName, Color = "Black" }; // Установите цвет по умолчанию или ваши логику
                        helper.GetEntities().Tag.Add(existingTag);
                    }

                    lastId = helper.GetEntities().TagOfClient.OrderByDescending(item => item.ID).Select(item => item.ID).FirstOrDefault();
                    newId = lastId + 1;

                    // Создайте новый объект TagOfClient и добавьте его к клиенту
                    TagOfClient newClientTag = new TagOfClient
                    {
                        ID = newId,
                        ClientID = firstClient.ID,
                        TagID = existingTag.ID
                    };

                    helper.GetEntities().TagOfClient.Add(newClientTag);
                    Save(); // Сохраните изменения в базе данных

                    // Обновите отображение тегов
                    UpdateTags();
                }
                else
                {
                    MessageBox.Show("Этот тег уже прикреплен к клиенту.");
                }
            }
        }

        private void btnDelTag_Click(object sender, RoutedEventArgs e)
        {
            var selectedTagsItem = lbTags.SelectedItem as ListBoxItem;
            if (selectedTagsItem != null)
            {
                var selectedTags = selectedTagsItem.Content?.ToString();
                if (selectedTags != null)
                {
                    var tag = helper.GetEntities().Tag.Where(t => t.Title == selectedTags).FirstOrDefault();
                    var clietnTag = firstClient.TagOfClient.FirstOrDefault(tc => tc.TagID == tag.ID);
                    helper.GetEntities().TagOfClient.Remove(clietnTag);
                }
            }
            else
            {
                MessageBox.Show("Вы не выбрали тег!");
                return;
            }
            //var selectedTags = ((ListBoxItem)lbTags.SelectedItem).Content.ToString();
            //if (selectedTags == null)
            //{
            //    MessageBox.Show("Вы не выбрали тег!");
            //    return;
            //}
            //else
            //{
            //    var tag = helper.GetEntities().Tag.Where(t => t.Title == selectedTags).FirstOrDefault();
            //    var clietnTag = firstClient.TagOfClient.FirstOrDefault(tc => tc.TagID == tag.ID);
            //    helper.GetEntities().TagOfClient.Remove(clietnTag);
            //}

            // Проверка, есть ли выбранные теги
            //if (selectedTags.Any())
            //{
            //    // Удалите соответствующие записи из базы данных
            //    foreach (var tag in selectedTags)
            //    {
            //        var clientTag = firstClient.TagOfClient.FirstOrDefault(tc => tc.TagID == tag.ID);
            //        if (clientTag != null)
            //        {
            //            helper.GetEntities().TagOfClient.Remove(clientTag);
            //        }
            //    }

            //    // Сохраните изменения
            Save();

            // Обновите ListBox с тегами
            UpdateTags();
            //}
            //else
            //{
            //    MessageBox.Show("Выберите теги для удаления.");
            //}
        }
    }
}

