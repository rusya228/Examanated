﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBA
{
    /// <summary>
    /// Логика взаимодействия для TeamWindow.xaml
    /// </summary>
    public partial class TeamWindow : Window
    {
        private VisitorMain previousWindow;
        public int choise = 0;
        public TeamWindow()
        {
            InitializeComponent();
            Load(choise);
        }

        public void Load(int choise)
        {
            if (choise == 0)
            {
                dgAtlantic.ItemsSource = helper.GetEntities().LoadTeamsByDivision("Atlantic");
                lbFirst.Content = "Atlantic";
                dgCentral.ItemsSource = helper.GetEntities().LoadTeamsByDivision("Central");
                lbSec.Content = "Central";
                dgSoutheast.ItemsSource = helper.GetEntities().LoadTeamsByDivision("Southeastern");
                lbThree.Content = "Southeast";
            }
            else
            {
                dgAtlantic.ItemsSource = helper.GetEntities().LoadTeamsByDivision("Northwestern");
                lbFirst.Content = "Northwest";
                dgCentral.ItemsSource = helper.GetEntities().LoadTeamsByDivision("Pacific");
                lbSec.Content = "Pacific";
                dgSoutheast.ItemsSource = helper.GetEntities().LoadTeamsByDivision("Southwestern");
                lbThree.Content = "Southwest";
            }
        }

        private void GoBack()
        {
            // Проверяем, создано ли уже предыдущее окно
            if (previousWindow == null)
            {
                // Если нет, создаем новый экземпляр
                previousWindow = new VisitorMain();
            }

            // Закрываем текущее окно
            this.Close();

            // Отображаем предыдущее окно
            previousWindow.Show();
        }
        private void btnBackWindow_Click(object sender, RoutedEventArgs e)
        {
            GoBack();
        }

        private void Button_East(object sender, RoutedEventArgs e)
        {
            choise = 0;
            Load(choise);
        }

        private void Button_West(object sender, RoutedEventArgs e)
        {
            choise = 1;
            Load(choise);
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            GoBack();
        }
    }
}
