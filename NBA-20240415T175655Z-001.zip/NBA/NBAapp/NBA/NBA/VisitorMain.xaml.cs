﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBA
{
    /// <summary>
    /// Логика взаимодействия для VisitorMain.xaml
    /// </summary>
    public partial class VisitorMain : Window
    {
        private MainWindow previousWindow;
        public VisitorMain()
        {
            InitializeComponent();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            GoBack();
        }

        private void btnBackWindow_Click(object sender, RoutedEventArgs e)
        {
            GoBack();
        }

        private void GoBack()
        {
            // Проверяем, создано ли уже предыдущее окно
            if (previousWindow == null)
            {
                // Если нет, создаем новый экземпляр
                previousWindow = new MainWindow();
            }

            // Закрываем текущее окно
            this.Close();

            // Отображаем предыдущее окно
            previousWindow.Show();
        }

        private void btnTeams_Click(object sender, RoutedEventArgs e)
        {
            TeamWindow TeamMain = new TeamWindow();

            // Скрываем текущее окно
            this.Hide();

            // Отображаем новое окно
            TeamMain.Show();
        }
    }
}
