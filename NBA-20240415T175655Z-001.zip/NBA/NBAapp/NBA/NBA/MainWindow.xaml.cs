﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;
using System.IO;

namespace NBA
{
    public partial class MainWindow : Window
    {
        private List<Pictures> pictures; // Список для хранения изображений
        private int currentImageIndex = 0; // Текущий индекс отображаемого изображения
        public MainWindow()
        {
            InitializeComponent();
            Load();
        }

        public void Load()
        {
            pictures = helper.GetEntities().Pictures.ToList();

            // Отобразите первые три изображения
            DisplayImages();

        }

        private void DisplayImages()
        {
            if (pictures.Count >= 3)
            {
                img1.Source = ConvertBytesToBitmapImage(pictures[currentImageIndex].Img);
                img2.Source = ConvertBytesToBitmapImage(pictures[(currentImageIndex + 1) % pictures.Count].Img);
                img3.Source = ConvertBytesToBitmapImage(pictures[(currentImageIndex + 2) % pictures.Count].Img);
            }
        }
        private void imgLeft_Click(object sender, RoutedEventArgs e)
        {
            // Уменьшаем индекс текущего изображения
            currentImageIndex -= 3;

            // Если достигли начала списка, перемещаемся к концу
            if (currentImageIndex < 0)
            {
                currentImageIndex = pictures.Count - 1;
            }

            // Отображаем изображения
            DisplayImages();
        }

        private void imgRight_Click(object sender, RoutedEventArgs e)
        {
            // Увеличиваем индекс текущего изображения
            currentImageIndex += 3;

            // Если достигли конца списка, перемещаемся к началу
            if (currentImageIndex >= pictures.Count)
            {
                currentImageIndex = 0;
            }

            // Отображаем изображения
            DisplayImages();
        }

        private ImageSource ConvertBytesToBitmapImage(byte[] imageData)
        {
            try
            {
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = new MemoryStream(imageData);
                bitmapImage.EndInit();
                return bitmapImage;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка преобразования байтов в BitmapImage: {ex.Message}");
                return null;
            }
        }

        private void btnVisitor_Click(object sender, RoutedEventArgs e)
        {
            VisitorMain VisMain = new VisitorMain();

            // Скрываем текущее окно
            this.Hide();

            // Отображаем новое окно
            VisMain.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }

    public class helper
    {
        private static NBAEntities1 entities;

        public static NBAEntities1 GetEntities(bool chmo = false)
        {
            if (chmo || entities == null)
            {

                entities = new NBAEntities1();
            }
            return entities;
        }
    }


}
